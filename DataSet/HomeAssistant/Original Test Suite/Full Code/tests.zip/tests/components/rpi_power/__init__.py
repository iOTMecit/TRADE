"""Tests for rpi_power."""
