"""The tests for Air Quality platforms."""
