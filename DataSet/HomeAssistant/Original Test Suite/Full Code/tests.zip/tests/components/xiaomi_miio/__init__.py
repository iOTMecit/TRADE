"""Tests for the Xiaomi Miio integration."""

TEST_MAC = "ab:cd:ef:gh:ij:kl"
