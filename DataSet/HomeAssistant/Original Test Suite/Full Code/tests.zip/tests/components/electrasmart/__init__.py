"""Tests for the Electra Air Conditioner integration."""
