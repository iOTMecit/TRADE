"""Tests for the Ecovacs integration."""
