"""Tests for the xiaomi component."""
