"""Tests for the yolink integration."""
