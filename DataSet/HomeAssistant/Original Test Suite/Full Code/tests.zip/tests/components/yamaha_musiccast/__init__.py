"""Tests for the MusicCast integration."""
