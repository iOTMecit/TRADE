"""Tests for the yamaha component."""
