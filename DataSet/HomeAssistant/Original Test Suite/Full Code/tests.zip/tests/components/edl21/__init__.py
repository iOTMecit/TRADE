"""Tests for the EDL21 integration."""
