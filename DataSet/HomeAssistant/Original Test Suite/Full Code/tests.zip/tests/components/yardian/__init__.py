"""Tests for the yardian integration."""
