"""Tests for Roborock integration."""
