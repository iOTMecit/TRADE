window.Lidarr = {
    apiRoot: '/api/v1',
    apiKey: '1234567890abcdef1234567890abcdef',
    release: '10.0.0.34882-develop',
    version: '10.0.0.34882',
    instanceName: 'Lidarr',
    branch: 'nightly',
    analytics: true,
    userHash: 'abcd1234',
    urlBase: '',
    isProduction: true
  };