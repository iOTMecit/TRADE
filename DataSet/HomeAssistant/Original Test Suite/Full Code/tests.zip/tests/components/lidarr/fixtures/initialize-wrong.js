window.Radarr = {
    apiRoot: '/api/v3',
    apiKey: '1234567890abcdef1234567890abcdef',
    release: '4.0.3.5849-develop',
    version: '4.0.3.5849',
    instanceName: 'Radarr',
    branch: 'nightly',
    analytics: true,
    userHash: 'abcd1234',
    urlBase: '',
    isProduction: true
  };