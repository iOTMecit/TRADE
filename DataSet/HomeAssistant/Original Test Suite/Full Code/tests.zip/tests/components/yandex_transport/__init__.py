"""Tests for the yandex transport platform."""
