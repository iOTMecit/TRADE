"""Tests for the Yale Smart Living integration."""
