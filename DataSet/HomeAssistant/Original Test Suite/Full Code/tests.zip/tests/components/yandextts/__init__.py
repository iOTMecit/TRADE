"""The tests for YandexTTS tts platforms."""
