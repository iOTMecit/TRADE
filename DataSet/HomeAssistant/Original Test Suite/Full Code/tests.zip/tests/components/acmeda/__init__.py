"""Tests for the Rollease Acmeda Automate integration."""
