"""Tests for LCN."""
