"""Tests for the Elgato Key Light integration."""
