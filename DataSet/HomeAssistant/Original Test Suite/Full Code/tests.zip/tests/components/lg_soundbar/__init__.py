"""Tests for the lg_soundbar component."""
