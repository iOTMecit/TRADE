"""Tests for the ROMY integration."""
