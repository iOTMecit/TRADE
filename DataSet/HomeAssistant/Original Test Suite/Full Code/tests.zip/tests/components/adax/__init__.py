"""Tests for the Adax integration."""
