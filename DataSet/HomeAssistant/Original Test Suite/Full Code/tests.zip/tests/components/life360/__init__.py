"""Tests for the Life360 integration."""
