"""Tests for the roon integration."""
