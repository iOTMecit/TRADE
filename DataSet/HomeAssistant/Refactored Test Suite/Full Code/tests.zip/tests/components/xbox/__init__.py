"""Tests for the xbox integration."""
