"""Tests for the Axis component."""
