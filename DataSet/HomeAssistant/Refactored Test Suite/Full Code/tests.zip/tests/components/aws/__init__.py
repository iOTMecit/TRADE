"""Tests for the aws component."""
