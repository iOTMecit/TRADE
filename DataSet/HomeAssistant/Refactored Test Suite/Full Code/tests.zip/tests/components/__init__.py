"""The tests for components."""
