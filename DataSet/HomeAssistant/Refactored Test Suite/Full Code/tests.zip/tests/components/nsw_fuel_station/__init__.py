"""Tests for the nsw_fuel_station component."""
