"""Tests for the Garages Amsterdam integration."""
