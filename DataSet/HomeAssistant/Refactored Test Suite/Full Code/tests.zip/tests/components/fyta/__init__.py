"""Tests for the Fyta integration."""
