"""Tests for the Abode component."""
