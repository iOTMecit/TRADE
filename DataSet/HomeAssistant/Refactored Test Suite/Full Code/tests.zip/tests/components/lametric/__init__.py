"""Tests for the LaMetric integration."""
