"""Tests for the html5 component."""
