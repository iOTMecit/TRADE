"""Tests for the Rhasspy integration."""
