"""Tests for the Ridwell integration."""
