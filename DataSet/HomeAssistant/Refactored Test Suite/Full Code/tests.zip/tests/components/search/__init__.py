"""Tests for the Search integration."""
