"""The tests for notification platforms."""
