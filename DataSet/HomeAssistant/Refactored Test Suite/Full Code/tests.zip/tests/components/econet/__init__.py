"""Tests for the Econet component."""
