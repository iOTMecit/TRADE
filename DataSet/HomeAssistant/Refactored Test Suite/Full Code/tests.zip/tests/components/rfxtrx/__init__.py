"""Tests for the rfxtrx component."""
