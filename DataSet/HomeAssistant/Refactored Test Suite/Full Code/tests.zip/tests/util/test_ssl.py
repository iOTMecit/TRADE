"""Test Home Assistant ssl utility functions."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from homeassistant.util.ssl import (
    SSL_CIPHER_LISTS,
    SSLCipherList,
    client_context,
    create_no_verify_ssl_context,
)


@pytest.fixture
def mock_sslcontext():
    """Mock the ssl lib."""
    ssl_mock = MagicMock(set_ciphers=Mock(return_value=True))
    return ssl_mock


def test_client_context(mock_sslcontext, param1='client_context()', param2='client_context(SSLCipherList.MODERN)', param3='client_context(SSLCipherList.INTERMEDIATE)'):
    with patch("homeassistant.util.ssl.ssl.SSLContext", return_value=mock_sslcontext):
        exec(param1)
        mock_sslcontext.set_ciphers.assert_not_called()
        exec(param2)
        mock_sslcontext.set_ciphers.assert_called_with(
            SSL_CIPHER_LISTS[SSLCipherList.MODERN]
        )
        exec(param3)
        mock_sslcontext.set_ciphers.assert_called_with(
            SSL_CIPHER_LISTS[SSLCipherList.INTERMEDIATE]
        )





def test_no_verify_ssl_context(mock_sslcontext) -> None:
	test_client_context(mock_sslcontext, param1='create_no_verify_ssl_context()', param2='create_no_verify_ssl_context(SSLCipherList.MODERN)', param3='create_no_verify_ssl_context(SSLCipherList.INTERMEDIATE)')















def test_ssl_context_caching() -> None:
    """Test that SSLContext instances are cached correctly."""

    assert client_context() is client_context(SSLCipherList.PYTHON_DEFAULT)
    assert create_no_verify_ssl_context() is create_no_verify_ssl_context(
        SSLCipherList.PYTHON_DEFAULT
    )
