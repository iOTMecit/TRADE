"""Tests for YAML util."""
