"""Group."""

MAGIC = 1
