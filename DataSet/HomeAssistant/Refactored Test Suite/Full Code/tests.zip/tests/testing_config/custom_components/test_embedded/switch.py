"""Switch platform for the embedded component."""


async def async_setup_platform(
    hass, config, async_add_entities_callback, discovery_info=None
):
    """Find and return test switches."""
