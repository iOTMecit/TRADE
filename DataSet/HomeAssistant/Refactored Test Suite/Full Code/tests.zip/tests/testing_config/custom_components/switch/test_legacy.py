"""Test switch platform for test_embedded component."""
