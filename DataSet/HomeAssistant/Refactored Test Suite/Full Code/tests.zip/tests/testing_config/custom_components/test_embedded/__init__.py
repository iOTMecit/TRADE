"""Component with embedded platforms."""

DOMAIN = "test_embedded"


async def async_setup(hass, config):
    """Mock config."""
    return True
