"""A collection of custom integrations used when running tests."""
