"""Provide a mock package component."""
