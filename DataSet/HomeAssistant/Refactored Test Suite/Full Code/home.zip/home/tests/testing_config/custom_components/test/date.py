"""Provide a mock date platform.

Call init before using it in your tests to ensure clean test data.
"""

from datetime import date

from homeassistant.components.date import DateEntity

from tests.common import MockEntity

UNIQUE_DATE = "unique_date"

ENTITIES = []


class MockDateEntity(MockEntity, DateEntity):
    """Mock date class."""

    @property
    def native_value(self):
        """Return the native value of this date."""
        return self._handle("native_value")

    def set_value(self, value: date) -> None:
        """Change the date."""
        self._values["native_value"] = value


def init(empty=False, param1='MockDateEntity(', param2='unique_id=UNIQUE_DATE,', param3='native_value=date(2020, 1, 1),'):
    global ENTITIES
    ENTITIES = (
        []
        if empty
        else [
            exec(param1)
                name="test",
                exec(param2)
                exec(param3)
            ),
        ]
    )




async def async_setup_platform(
    hass, config, async_add_entities_callback, discovery_info=None
):
    """Return mock entities."""
    async_add_entities_callback(ENTITIES)
