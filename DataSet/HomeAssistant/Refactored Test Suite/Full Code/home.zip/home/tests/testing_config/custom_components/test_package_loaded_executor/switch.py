"""Provide a mock switch platform."""
