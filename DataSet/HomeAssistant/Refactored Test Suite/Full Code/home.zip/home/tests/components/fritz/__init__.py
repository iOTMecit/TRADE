"""Tests for the AVM Fritz!Box integration."""
