"""Tests for the SENZ integration."""
