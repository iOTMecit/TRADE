"""Define tests for the Luftdaten component."""
