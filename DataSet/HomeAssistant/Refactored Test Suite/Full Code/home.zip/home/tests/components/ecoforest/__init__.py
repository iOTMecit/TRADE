"""Tests for the Ecoforest integration."""
