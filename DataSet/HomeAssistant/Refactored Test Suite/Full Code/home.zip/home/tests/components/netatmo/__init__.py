"""The tests for Netatmo platforms."""
