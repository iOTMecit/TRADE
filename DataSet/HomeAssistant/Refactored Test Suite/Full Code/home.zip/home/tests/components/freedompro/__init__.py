"""Tests for the Freedompro integration."""
