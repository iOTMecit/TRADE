"""Tests for the Rituals Perfume Genie integration."""
