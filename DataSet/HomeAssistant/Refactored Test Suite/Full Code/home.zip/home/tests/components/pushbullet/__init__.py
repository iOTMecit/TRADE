"""Tests for the pushbullet component."""

from homeassistant.const import CONF_API_KEY, CONF_NAME

MOCK_CONFIG = {CONF_NAME: "pushbullet", CONF_API_KEY: "MYAPIKEY"}
