"""Define tests for the Tile component."""
