"""Tests for the Risco integration."""
