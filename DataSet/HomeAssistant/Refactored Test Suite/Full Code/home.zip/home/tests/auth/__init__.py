"""Tests for the Home Assistant auth module."""
