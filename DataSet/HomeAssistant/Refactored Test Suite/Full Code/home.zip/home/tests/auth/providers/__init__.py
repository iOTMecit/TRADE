"""Tests for the auth providers."""
