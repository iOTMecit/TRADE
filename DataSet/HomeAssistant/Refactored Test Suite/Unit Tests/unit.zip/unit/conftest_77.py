"""zerproc conftest."""

from tests.components.light.conftest import mock_light_profiles  # noqa: F401
