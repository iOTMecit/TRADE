"""Provide a mock integration."""
