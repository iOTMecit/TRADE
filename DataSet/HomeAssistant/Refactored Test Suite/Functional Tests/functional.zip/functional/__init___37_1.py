"""Tests for the facebook component."""
