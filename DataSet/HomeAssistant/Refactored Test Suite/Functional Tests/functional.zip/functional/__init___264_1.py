"""Tests for the SiteSage Emonitor integration."""
