"""Test package for Sensirion BLE sensor integration."""
