"""The tests for Geo Location platforms."""
