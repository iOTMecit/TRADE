"""Tests for the A. O. Smith integration."""
