"""Tests for the Android TV Remote integration."""
