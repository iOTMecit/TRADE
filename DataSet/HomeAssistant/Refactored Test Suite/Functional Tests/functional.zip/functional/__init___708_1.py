"""Tests for the logbook component."""
