"""Tests for the Bosch SHC integration."""
