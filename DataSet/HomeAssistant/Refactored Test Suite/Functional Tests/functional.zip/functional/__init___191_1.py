"""Tests for the logger component."""
