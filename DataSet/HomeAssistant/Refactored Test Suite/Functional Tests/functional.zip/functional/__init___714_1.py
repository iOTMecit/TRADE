"""generic_thermostat tests."""
