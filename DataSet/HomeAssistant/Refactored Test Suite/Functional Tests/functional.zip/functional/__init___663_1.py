"""Tests for the Govee Light local integration."""
