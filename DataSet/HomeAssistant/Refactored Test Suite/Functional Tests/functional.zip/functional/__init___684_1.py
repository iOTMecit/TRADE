"""Tests for the zone component."""
