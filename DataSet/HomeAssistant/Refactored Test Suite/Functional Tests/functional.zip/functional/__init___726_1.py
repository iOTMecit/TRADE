"""Tests for the shopping_list component."""
