"""Tests for the dte_energy_bridge component."""
