"""Tests for the caldav component."""
