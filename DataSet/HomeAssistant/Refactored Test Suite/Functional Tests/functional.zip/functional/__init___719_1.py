"""Tests for the qld_bushfire component."""
