"""Tests for the QNAP integration."""
