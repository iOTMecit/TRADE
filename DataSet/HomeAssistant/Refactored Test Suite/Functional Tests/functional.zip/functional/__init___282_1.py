"""Tests for the google_domains component."""
