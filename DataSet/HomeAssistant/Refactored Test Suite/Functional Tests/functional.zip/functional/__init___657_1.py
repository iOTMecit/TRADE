"""Tests for the universal component."""
