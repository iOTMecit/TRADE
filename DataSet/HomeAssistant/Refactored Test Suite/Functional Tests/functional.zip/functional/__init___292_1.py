"""Test for the lutron integration."""
