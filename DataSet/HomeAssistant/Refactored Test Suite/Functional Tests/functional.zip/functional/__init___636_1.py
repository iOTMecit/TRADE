"""Tests for the openhardwaremonitor component."""
