"""Tests for the Brottsplatskartan integration."""
