"""Tests for the apprise component."""
