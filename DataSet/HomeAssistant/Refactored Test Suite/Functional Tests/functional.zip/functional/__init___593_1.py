"""Tests for the Midea ccm15 AC Controller integration."""
