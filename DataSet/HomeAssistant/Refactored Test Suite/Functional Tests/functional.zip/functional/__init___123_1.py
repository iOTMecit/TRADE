"""Tests for scene component."""
