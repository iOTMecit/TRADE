"""Tests for the Network UPS Tools (NUT) integration."""
