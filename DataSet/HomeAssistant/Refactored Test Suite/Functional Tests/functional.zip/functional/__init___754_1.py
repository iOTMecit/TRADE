"""Tests for the easyEnergy integration."""
