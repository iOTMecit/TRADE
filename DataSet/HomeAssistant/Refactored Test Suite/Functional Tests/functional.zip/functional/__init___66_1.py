"""Tests for the GPSLogger component."""
