"""The tests for camera platforms."""
