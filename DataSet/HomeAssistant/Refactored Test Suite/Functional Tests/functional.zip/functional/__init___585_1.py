"""Tests for the Landis+Gyr Heat Meter component."""
