"""Tests for the Network Configuration integration."""
