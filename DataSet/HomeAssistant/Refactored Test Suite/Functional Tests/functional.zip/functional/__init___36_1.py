"""Tests for Hass.io component."""

SUPERVISOR_TOKEN = "123456"
