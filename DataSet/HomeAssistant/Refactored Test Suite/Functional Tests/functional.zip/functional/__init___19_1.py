"""Tests for the Opentherm Gateway integration."""
