"""Tests for the Zeversolar integration."""
