"""Tests for the TP-Link Omada integration."""
