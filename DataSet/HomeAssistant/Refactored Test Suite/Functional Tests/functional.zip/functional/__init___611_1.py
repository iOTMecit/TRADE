"""The tests for Automation."""
