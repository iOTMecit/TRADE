"""Tests for the filter component."""
