"""Tests for the PVOutput integration."""
