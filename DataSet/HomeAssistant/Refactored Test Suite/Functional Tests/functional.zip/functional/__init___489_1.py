"""Tests for the Google integration."""
