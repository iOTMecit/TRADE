"""Tests for the Azure DevOps integration."""
