"""The tests for Number integration."""
