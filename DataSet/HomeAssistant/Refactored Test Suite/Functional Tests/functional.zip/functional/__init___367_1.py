"""Tests for the AirTouch4 integration."""
