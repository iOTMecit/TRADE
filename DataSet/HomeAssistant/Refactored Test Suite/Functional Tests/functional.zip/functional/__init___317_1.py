"""Tests for the lawn mower integration."""
