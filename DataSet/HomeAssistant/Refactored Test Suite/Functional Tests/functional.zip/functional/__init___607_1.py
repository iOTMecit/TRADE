"""Tests for the Omnilogic integration."""
