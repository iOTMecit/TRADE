"""Tests for the season component."""
