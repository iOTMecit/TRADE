"""Tests for the uvc component."""
