"""Test env for timer component."""
