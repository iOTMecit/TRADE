"""Tests for fan platforms."""
