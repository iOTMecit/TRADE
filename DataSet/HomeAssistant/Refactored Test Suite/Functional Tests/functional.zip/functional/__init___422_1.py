"""Tests for the Netgear LTE component."""
