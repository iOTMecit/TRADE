"""Tests for the Google Translate integration."""
