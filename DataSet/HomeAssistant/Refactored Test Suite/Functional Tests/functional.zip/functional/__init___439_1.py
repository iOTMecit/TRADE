"""Tests for the Litter-Robot Component."""
