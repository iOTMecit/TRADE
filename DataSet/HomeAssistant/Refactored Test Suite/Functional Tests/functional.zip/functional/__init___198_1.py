"""Tests for the bsblan integration."""
