"""Tests for the Radio Browser integration."""
