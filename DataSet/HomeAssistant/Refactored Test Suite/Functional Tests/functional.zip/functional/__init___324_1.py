"""Tests for the APRS component."""
