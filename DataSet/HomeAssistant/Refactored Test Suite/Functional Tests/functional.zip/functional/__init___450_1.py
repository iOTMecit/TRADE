"""Tests for the Geofency component."""
