"""Tests for the Tuya component."""
