"""Define tests for the lupusec component."""
