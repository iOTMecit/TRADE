"""Tests for the Fibaro integration."""
