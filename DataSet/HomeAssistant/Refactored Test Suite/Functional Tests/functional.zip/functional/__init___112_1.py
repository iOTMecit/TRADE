"""Tests for the bang_olufsen integration."""
