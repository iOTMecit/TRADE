"""Tests for the ffmpeg component."""
