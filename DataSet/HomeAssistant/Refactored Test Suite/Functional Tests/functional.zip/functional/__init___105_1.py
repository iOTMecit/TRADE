"""Tests for the Open Exchange Rates integration."""
