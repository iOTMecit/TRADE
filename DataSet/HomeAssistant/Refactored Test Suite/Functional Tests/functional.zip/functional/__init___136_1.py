"""Tests for the Rachio integration."""
