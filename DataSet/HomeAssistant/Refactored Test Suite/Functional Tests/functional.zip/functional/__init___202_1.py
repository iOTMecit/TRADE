"""The tests for mailbox platforms."""
