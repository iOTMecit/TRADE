"""Tests for the Blink component."""
