"""Brunt tests."""
