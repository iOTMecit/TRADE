"""The tests for the nexbus component."""
