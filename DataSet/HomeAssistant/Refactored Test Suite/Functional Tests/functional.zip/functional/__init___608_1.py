"""Tests for the Google Generative AI Conversation integration."""
