"""Tests for the QNAP QSW integration."""
