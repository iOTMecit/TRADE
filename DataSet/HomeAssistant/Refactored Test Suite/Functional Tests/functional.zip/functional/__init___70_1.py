"""Tests for the qwikswitch component."""
