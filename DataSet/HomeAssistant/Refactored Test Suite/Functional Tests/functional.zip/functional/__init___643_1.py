"""Tests for the zodiac component."""
