"""Tests for the Frontier Silicon integration."""
