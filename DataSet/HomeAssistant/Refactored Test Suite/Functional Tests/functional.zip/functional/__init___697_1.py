"""Tests for the Gree Climate integration."""
