"""Tests for the iRobot Roomba integration."""
