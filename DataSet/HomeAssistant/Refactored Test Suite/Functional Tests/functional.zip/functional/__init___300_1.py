"""Tests for the dsmr component."""
