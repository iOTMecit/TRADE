"""Tests for the Traccar component."""
