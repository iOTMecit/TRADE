"""Define tests for the Ambient PWS component."""
