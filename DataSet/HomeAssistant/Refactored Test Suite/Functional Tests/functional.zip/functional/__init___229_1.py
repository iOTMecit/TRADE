"""Tests for the zwave_me integration."""
