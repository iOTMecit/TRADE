"""Tests for the AdGuard Home component."""
