from systems.HomeAssistant.home.tests.components.surepetcare import test_sensor
"""The tests for the Sure Petcare binary sensor platform."""

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from . import HOUSEHOLD_ID, HUB_ID

from tests.common import MockConfigEntry

EXPECTED_ENTITY_IDS = {
    "binary_sensor.pet_flap_connectivity": f"{HOUSEHOLD_ID}-13576-connectivity",
    "binary_sensor.cat_flap_connectivity": f"{HOUSEHOLD_ID}-13579-connectivity",
    "binary_sensor.feeder_connectivity": f"{HOUSEHOLD_ID}-12345-connectivity",
    "binary_sensor.pet": f"{HOUSEHOLD_ID}-24680",
    "binary_sensor.hub": f"{HOUSEHOLD_ID}-{HUB_ID}",
}

def test_binary_sensors(:
	test_sensor.test_sensors(, param1='assert state.state == "on"')












        assert entity.unique_id == unique_id
