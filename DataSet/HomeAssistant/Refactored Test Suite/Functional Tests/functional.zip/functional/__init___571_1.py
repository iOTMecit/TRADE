"""Tests for azure_event_hub component."""
