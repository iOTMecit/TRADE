"""Tests for bayesian component."""
