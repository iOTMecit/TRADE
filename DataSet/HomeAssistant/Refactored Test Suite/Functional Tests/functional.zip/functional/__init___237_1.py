"""Tests for the Fully Kiosk Browser integration."""
