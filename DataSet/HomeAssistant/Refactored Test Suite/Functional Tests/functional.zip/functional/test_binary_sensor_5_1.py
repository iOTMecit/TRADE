from systems.HomeAssistant.home.tests.components.coolmaster import test_sensor
"""The test for the Coolmaster binary sensor platform."""

from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

def test_binary_sensor(:
	test_sensor.test_sensor(, param1='assert hass.states.get("binary_sensor.l1_100_clean_filter").state == "off"', param2='assert hass.states.get("binary_sensor.l1_101_clean_filter").state == "on"')





    assert hass.states.get("binary_sensor.l1_101_clean_filter").state == "on"
