"""Constants for test_package custom component."""

TEST = 5
