"""Tests for the uptime component."""
