"""Tests for the GPSD integration."""
