"""Tests for the color_extractor component."""
