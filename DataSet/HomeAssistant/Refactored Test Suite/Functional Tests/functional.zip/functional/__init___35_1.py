"""Tests for the qBittorrent integration."""
