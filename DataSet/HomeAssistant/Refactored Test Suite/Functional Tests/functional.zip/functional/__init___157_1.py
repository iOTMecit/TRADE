"""Tests for nx584 component."""
