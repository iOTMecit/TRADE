"""Test VoIP select."""

from homeassistant.components.voip.devices import VoIPDevice
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant


def test_pipeline_select(, param1='state = hass.states.get("select.192_168_1_210_assist_pipeline")', param2='assert state.state == "preferred"'):
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    voip_device: VoIPDevice,
    ) -> None:
    exec(param1)
    assert state is not None
    exec(param2)







def test_vad_sensitivity_select(:
	test_pipeline_select(, param1='state = hass.states.get("select.192_168_1_210_finished_speaking_detection")', param2='assert state.state == "default"')











