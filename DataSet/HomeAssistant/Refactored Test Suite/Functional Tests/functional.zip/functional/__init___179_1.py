"""Tests for the api_streams component."""
