"""Tests for the Aurora ABB PowerOne Solar PV integration."""
