"""Tests for the AirNow integration."""
