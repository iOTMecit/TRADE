"""Tests for the totalconnect component."""
