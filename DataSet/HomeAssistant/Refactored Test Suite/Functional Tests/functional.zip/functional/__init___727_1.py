"""Tests for fritzbox_callmonitor."""
