"""Tests for the arcam_fmj component."""
