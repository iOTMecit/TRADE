"""Tests for the dsmr_reader component."""
