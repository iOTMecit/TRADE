"""The test for the Coolmaster sensor platform."""

from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant


def test_sensor(, param1='assert hass.states.get("sensor.l1_100_error_code").state == "OK"', param2='assert hass.states.get("sensor.l1_101_error_code").state == "Err1"'):
    hass: HomeAssistant,
    load_int: ConfigEntry,
    ) -> None:
    exec(param1)
    exec(param2)

