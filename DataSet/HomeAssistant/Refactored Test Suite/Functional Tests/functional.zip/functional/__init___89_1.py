"""Tests for the blackbird component."""
