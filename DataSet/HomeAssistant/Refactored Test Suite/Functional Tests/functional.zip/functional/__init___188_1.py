"""Tests for the schedule integration."""
