"""Tests for apache_kafka component."""
