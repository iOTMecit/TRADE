"""Tests for the geo_rss_events component."""
