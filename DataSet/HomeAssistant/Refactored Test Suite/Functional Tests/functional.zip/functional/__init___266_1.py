"""Tests for the Tesla Powerwall integration."""
