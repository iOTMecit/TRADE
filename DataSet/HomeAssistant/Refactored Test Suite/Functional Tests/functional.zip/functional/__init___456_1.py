"""Tests for the Local Calendar integration."""
