"""Fast.com integration tests."""
