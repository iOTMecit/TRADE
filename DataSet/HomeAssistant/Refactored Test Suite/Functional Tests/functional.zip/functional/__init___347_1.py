"""Tests for the Anthem A/V Receivers integration."""
