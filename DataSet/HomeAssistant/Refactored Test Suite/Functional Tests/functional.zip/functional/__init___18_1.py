"""Tests for the upnp component."""
