"""Tests for Lovelace."""
