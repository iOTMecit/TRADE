"""The tests for the demo calendar component."""
