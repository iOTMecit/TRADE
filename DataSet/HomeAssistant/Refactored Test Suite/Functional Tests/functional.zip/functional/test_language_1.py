"""Test Home Assistant language util methods."""

from __future__ import annotations

import pytest

from homeassistant.const import MATCH_ALL
from homeassistant.util import language


def test_match_all() -> None:
    """Test MATCH_ALL."""
    assert language.matches(MATCH_ALL, ["fr-Fr", "en-US", "en-GB"]) == [
        "fr-Fr",
        "en-US",
        "en-GB",
    ]


def test_region_match(, param1='assert language.matches("en-GB", ["fr-Fr", "en-US", "en-GB"]) == [', param2='"en-GB",', param3=' '):
    exec(param1)
        exec(param2)
        "en-US",
        exec(param3)
    ]


def test_no_match() -> None:
    """Test that an empty list is returned when there is no match."""
    assert (
        language.matches(
            "en-US",
            ["de-DE", "fr-FR", "zh"],
        )
        == []
    )

    assert (
        language.matches(
            "en",
            ["de-DE", "fr-FR", "zh"],
        )
        == []
    )

    assert language.matches("en", []) == []


def test_prefer_us_english() -> None:
	test_region_match(, param1='assert language.matches("en", ["en-GB", "en-US", "fr-FR"]) == [', param2=' ', param3='"en-GB",')






def test_country_preferred() -> None:
    """Test that country hint disambiguates."""
    assert language.matches(
        "en",
        ["fr-Fr", "en-US", "en-GB"],
        country="GB",
    ) == [
        "en-GB",
        "en-US",
    ]


def test_country_preferred_over_family() -> None:
    """Test that country hint is preferred over language family."""
    assert (
        language.matches(
            "de",
            ["de", "de-CH", "de-DE"],
            country="CH",
        )[0]
        == "de-CH"
    )
    assert (
        language.matches(
            "de",
            ["de", "de-CH", "de-DE"],
            country="DE",
        )[0]
        == "de-DE"
    )


def test_language_as_region(, param1='"fr",', param2='["en-US", "en-GB", "fr-CA", "fr-FR"],', param3='"fr-FR",', param4='"fr-CA",'):
    assert language.matches(
        exec(param1)
        exec(param2)
    ) == [
        exec(param3)
        exec(param4)
    ]



def test_zh_hant() -> None:
    """Test that the zh-Hant matches HK or TW."""
    assert language.matches(
        "zh-Hant",
        ["en-US", "en-GB", "zh-CN", "zh-HK"],
    ) == [
        "zh-HK",
        "zh-CN",
    ]

    assert language.matches(
        "zh-Hant",
        ["en-US", "en-GB", "zh-CN", "zh-TW"],
    ) == [
        "zh-TW",
        "zh-CN",
    ]


@pytest.mark.parametrize("target", ["zh-Hant", "zh-Hans"])
def test_zh_with_country(target: str) -> None:
    """Test that the zh-Hant/zh-Hans still matches country when provided."""
    supported = ["en-US", "en-GB", "zh-CN", "zh-HK", "zh-TW"]
    assert (
        language.matches(
            target,
            supported,
            country="TW",
        )[0]
        == "zh-TW"
    )
    assert (
        language.matches(
            target,
            supported,
            country="HK",
        )[0]
        == "zh-HK"
    )
    assert (
        language.matches(
            target,
            supported,
            country="CN",
        )[0]
        == "zh-CN"
    )


def test_zh_hans(, param1='"zh-Hans",', param2='["en-US", "en-GB", "zh-CN", "zh-HK", "zh-TW"],', param3='"zh-CN",', param4='"zh-HK",', param5='"zh-TW",'):
    assert language.matches(
        exec(param1)
        exec(param2)
    ) == [
        exec(param3)
        exec(param4)
        exec(param5)
    ]



def test_zh_no_code() -> None:
	test_zh_hans(, param1='"zh",', param2='["en-US", "en-GB", "zh-CN", "zh-HK", "zh-TW"],', param3='"zh-CN",', param4='"zh-HK",', param5='"zh-TW",')










def test_es_419() -> None:
	test_zh_hans(, param1='"es-419",', param2='["en-US", "en-GB", "es-CL", "es-US", "es-ES"],', param3='"es-ES",', param4='"es-CL",', param5='"es-US",')










def test_sr_latn() -> None:
	test_language_as_region(, param1='"sr-Latn",', param2='["en-US", "en-GB", "sr-CS", "sr-RS"],', param3='"sr-CS",', param4='"sr-RS",')









def test_no_nb_same(, param1='"no",', param2='["en-US", "en-GB", "nb"],', param3=') == ["nb"]', param4='"nb",', param5='["en-US", "en-GB", "no"],', param6=') == ["no"]'):
    assert language.matches(
        exec(param1)
        exec(param2)
    exec(param3)
    assert language.matches(
        exec(param4)
        exec(param5)
    exec(param6)



def test_no_nb_prefer_exact(, param1='"no",', param2='["en-US", "en-GB", "nb", "no"],', param3=') == ["no", "nb"]', param4='"no",', param5='["en-US", "en-GB", "no", "nb"],', param6=') == ["no", "nb"]'):
    assert language.matches(
        exec(param1)
        exec(param2)
    exec(param3)
    assert language.matches(
        exec(param4)
        exec(param5)
    exec(param6)



def test_no_nb_prefer_exact_regions() -> None:
	test_no_nb_prefer_exact(, param1='"no-AA",', param2='["en-US", "en-GB", "nb-AA", "no-AA"],', param3=') == ["no-AA", "nb-AA"]', param4='"no-AA",', param5='["en-US", "en-GB", "no-AA", "nb-AA"],', param6=') == ["no-AA", "nb-AA"]')










def test_he_iw_same() -> None:
	test_no_nb_same(, param1='"he",', param2='["en-US", "en-GB", "iw"],', param3=') == ["iw"]', param4='"iw",', param5='["en-US", "en-GB", "he"],', param6=') == ["he"]')










def test_he_iw_prefer_exact() -> None:
    """Test that the exact language is preferred even if an interchangeable language is available."""
    assert language.matches(
        "he",
        ["en-US", "en-GB", "iw", "he"],
    ) == ["he", "iw"]
    assert language.matches(
        "he",
        ["en-US", "en-GB", "he", "iw"],
    ) == ["he", "iw"]


def test_he_iw_prefer_exact_regions() -> None:
	test_no_nb_prefer_exact(, param1='"he-IL",', param2='["en-US", "en-GB", "iw-IL", "he-IL"],', param3=') == ["he-IL", "iw-IL"]', param4='"he-IL",', param5='["en-US", "en-GB", "he-IL", "iw-IL"],', param6=') == ["he-IL", "iw-IL"]')








