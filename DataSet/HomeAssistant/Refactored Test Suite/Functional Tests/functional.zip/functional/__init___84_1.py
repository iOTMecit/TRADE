"""Tests for the opnsense component."""
