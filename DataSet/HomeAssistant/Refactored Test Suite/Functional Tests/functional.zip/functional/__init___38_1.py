"""Tests for the File Upload integration."""
