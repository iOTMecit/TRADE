"""Tests for the Bring! integration."""
