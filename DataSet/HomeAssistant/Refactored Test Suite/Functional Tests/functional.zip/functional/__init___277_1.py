"""Tests for the startca component."""
