"""Tests of the EnOcean integration."""
