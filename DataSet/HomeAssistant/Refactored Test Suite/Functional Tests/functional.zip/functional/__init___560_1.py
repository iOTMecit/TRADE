"""Tests for the V2C integration."""
