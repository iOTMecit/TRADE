"""Tests for the Linn / OpenHome integration."""
