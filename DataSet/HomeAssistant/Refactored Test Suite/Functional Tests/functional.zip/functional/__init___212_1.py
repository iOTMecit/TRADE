"""Tests for the Enphase Envoy integration."""
