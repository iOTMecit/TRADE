"""Constants for Husqvarna Automower tests."""

CLIENT_ID = "1234"
CLIENT_SECRET = "5678"
TEST_MOWER_ID = "c7233734-b219-4287-a173-08e3643f89f0"
USER_ID = "123"
