"""Tests for the Zeroconf component."""
