"""Tests for the Sense integration."""
