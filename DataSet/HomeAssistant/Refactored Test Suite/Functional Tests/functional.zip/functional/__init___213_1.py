"""Tests for the Schlage integration."""
