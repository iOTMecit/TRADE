"""Tests for the UptimeRobot integration."""
