"""Tests for the ZHA component."""
