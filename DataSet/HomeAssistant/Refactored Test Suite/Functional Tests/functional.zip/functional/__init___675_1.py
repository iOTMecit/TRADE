"""Tests for trend component."""
