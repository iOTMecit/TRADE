"""Tests for the script component."""
