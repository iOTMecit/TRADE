"""Tests for the OpenGarage integration."""
