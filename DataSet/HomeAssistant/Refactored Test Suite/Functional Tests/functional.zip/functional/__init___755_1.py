"""Tests for the Honeywell Lyric integration."""
