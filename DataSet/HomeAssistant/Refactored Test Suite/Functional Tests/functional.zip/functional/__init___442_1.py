"""Tests for the Plum Lightpad integration."""
