"""The tests for the Select integration."""
