"""Tests for the Bluetooth Adapters integration."""
