"""Tests for the august component."""
