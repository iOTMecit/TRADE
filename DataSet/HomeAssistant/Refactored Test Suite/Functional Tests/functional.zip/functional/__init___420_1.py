"""Tests for the Lidarr component."""
