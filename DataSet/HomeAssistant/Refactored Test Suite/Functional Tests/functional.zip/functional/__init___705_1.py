"""Bluetooth tests for ESPHome."""
