"""Tests for the everlights component."""
