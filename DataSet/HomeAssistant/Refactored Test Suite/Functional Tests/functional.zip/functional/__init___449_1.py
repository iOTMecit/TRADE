"""Tests for the rss_feed_template component."""
