"""Constants for the button entity component tests."""

TEST_DOMAIN = "test"
