"""Tests for the Toon component."""
