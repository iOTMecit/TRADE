"""Tests for the Loqed integration."""
