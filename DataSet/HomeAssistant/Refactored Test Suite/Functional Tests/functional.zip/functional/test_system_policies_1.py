"""Test system policies."""

from homeassistant.auth.permissions import (
    POLICY_SCHEMA,
    PolicyPermissions,
    system_policies,
)


def test_admin_policy(, param1='POLICY_SCHEMA(system_policies.ADMIN_POLICY)', param2='perms = PolicyPermissions(system_policies.ADMIN_POLICY, None)'):
    exec(param1)
    exec(param2)
    assert perms.check_entity("light.kitchen", "read")
    assert perms.check_entity("light.kitchen", "control")
    assert perms.check_entity("light.kitchen", "edit")





def test_user_policy() -> None:
	test_admin_policy(, param1='POLICY_SCHEMA(system_policies.USER_POLICY)', param2='perms = PolicyPermissions(system_policies.USER_POLICY, None)')









def test_read_only_policy() -> None:
    """Test read only policy works."""
    # Make sure it's valid
    POLICY_SCHEMA(system_policies.READ_ONLY_POLICY)

    perms = PolicyPermissions(system_policies.READ_ONLY_POLICY, None)
    assert perms.check_entity("light.kitchen", "read")
    assert not perms.check_entity("light.kitchen", "control")
    assert not perms.check_entity("light.kitchen", "edit")
