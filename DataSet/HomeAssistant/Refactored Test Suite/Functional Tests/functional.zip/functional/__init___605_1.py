"""The tests for vacuum platforms."""
