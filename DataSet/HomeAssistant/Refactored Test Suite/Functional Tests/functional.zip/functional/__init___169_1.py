"""Tests for the Energy integration."""
