"""Tests for the Locative component."""
