"""An integration with several platforms used with unit tests."""
