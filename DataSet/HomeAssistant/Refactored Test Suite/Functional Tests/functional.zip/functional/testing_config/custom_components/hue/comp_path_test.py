"""Custom platform for a built-in component, should not be allowed."""
