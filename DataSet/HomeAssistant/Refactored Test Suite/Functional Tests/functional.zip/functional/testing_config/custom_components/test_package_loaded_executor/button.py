"""Provide a mock button platform."""
