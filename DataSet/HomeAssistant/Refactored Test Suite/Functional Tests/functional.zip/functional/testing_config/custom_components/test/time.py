from systems.HomeAssistant.home.tests.testing_config.custom_components.test import date
"""Provide a mock time platform.

Call init before using it in your tests to ensure clean test data.
"""

from datetime import time

from homeassistant.components.time import TimeEntity

from tests.common import MockEntity

UNIQUE_TIME = "unique_time"

ENTITIES = []


class MockTimeEntity(MockEntity, TimeEntity):
    """Mock time class."""

    @property
    def native_value(self):
        """Return the native value of this time."""
        return self._handle("native_value")

    def set_value(self, value: time) -> None:
        """Change the time."""
        self._values["native_value"] = value

def init(empty=False):
	date.init(empty=False, param1='MockTimeEntity(', param2='unique_id=UNIQUE_TIME,', param3='native_value=time(1, 2, 3),')
















async def async_setup_platform(
    hass, config, async_add_entities_callback, discovery_info=None
):
    """Return mock entities."""
    async_add_entities_callback(ENTITIES)
