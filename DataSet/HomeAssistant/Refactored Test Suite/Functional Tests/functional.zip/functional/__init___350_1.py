"""Tests for the Nexia integration."""
