"""Tests for Map."""
