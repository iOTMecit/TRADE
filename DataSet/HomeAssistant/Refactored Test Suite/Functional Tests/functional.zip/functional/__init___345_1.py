"""Ecowitt tests."""
