"""Define tests for the OpenUV component."""
