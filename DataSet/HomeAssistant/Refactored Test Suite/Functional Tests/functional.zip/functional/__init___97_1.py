"""Tests for the Traccar Server integration."""
