"""Tests for the buienradar component."""
