"""Tests for the Linear Garage Door integration."""
