"""The tests for AlarmDecoder integration."""
