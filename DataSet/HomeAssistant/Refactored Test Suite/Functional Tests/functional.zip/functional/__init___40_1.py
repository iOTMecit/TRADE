"""Tests for the Open-Meteo integration."""
