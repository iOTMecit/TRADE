"""Tests for the google_wifi component."""
