"""Define AirNow response fixture data."""
