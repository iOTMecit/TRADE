"""Tests for the notify_events integration."""
