"""The tests for the Button integration."""
