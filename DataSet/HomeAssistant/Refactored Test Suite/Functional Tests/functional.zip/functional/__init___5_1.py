"""Configuration that's used when running tests."""
