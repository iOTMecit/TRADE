"""Tests for the Nextcloud integration."""
