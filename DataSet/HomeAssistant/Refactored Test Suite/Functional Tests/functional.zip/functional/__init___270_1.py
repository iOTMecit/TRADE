"""Tests for google_pubsub component."""
