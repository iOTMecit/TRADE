"""Tests for the launch_library component."""
