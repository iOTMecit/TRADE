"""Tests for the usgs_earthquakes_feed component."""
