"""Constants for cert_expiry tests."""

PORT = 443
HOST = "example.com"
