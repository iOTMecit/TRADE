"""Tests for the numato integration."""
