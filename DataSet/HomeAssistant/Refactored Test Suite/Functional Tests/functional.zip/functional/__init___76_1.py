"""Tests for the rainbird integration."""
