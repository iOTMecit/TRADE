"""Tests for the EnergyZero integration."""
