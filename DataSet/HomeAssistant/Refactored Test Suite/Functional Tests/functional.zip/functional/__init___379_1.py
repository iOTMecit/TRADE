"""Tests for the analytics integration."""
