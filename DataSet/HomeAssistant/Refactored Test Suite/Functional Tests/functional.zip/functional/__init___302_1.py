"""Tests for the alert component."""
