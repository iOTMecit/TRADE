"""Tests for the AEMET OpenData integration."""
