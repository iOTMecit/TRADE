"""Tests for the zerproc integration."""
