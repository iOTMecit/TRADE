"""Tests for the Mailgun component."""
