"""Tests for the openalpr_cloud component."""
