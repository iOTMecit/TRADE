"""Tests for the Electric Kiwi integration."""
