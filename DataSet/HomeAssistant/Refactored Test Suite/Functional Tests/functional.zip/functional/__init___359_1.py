"""Tests for emulated_kasa."""
