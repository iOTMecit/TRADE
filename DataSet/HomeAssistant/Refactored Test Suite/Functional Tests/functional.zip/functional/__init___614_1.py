"""The tests for the event integration."""
