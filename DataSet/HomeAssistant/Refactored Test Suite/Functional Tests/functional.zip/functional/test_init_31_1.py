"""Tests for the blueprint init."""
