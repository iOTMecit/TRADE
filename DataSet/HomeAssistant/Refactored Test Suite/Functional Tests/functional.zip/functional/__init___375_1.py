"""Tests for the Dynalite component."""
