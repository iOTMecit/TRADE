"""Tests for the pvpc_hourly_pricing integration."""
