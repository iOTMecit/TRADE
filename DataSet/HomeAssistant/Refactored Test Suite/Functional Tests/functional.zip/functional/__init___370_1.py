"""Tests for the Google Mail integration."""
