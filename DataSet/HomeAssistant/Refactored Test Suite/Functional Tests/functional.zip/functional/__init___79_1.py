"""Tests for the OpenWeatherMap integration."""
