"""Tests for the shell_command component."""
