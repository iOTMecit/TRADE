"""Tests for the UniFi Network integration."""
