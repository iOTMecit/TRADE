"""Tests for the PoolSense integration."""
