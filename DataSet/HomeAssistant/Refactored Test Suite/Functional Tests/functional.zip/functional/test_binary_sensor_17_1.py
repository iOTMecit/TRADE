from systems.HomeAssistant.home.tests.components.netgear_lte import test_sensor
"""The tests for Netgear LTE binary sensor platform."""

from syrupy.assertion import SnapshotAssertion

from homeassistant.components.binary_sensor import DOMAIN as BINARY_SENSOR_DOMAIN
from homeassistant.components.netgear_lte.const import DOMAIN
from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

def test_binary_sensors(:
	test_sensor.test_sensors(, param1='if entity_entry.domain != BINARY_SENSOR_DOMAIN:')
















        )
