"""Tests for the blebox component."""
