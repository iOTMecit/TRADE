"""Tests for the Goodwe integration."""
