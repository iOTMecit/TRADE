"""Tests for the freedns component."""
