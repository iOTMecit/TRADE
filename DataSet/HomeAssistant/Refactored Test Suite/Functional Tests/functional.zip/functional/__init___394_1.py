"""Tests for the no_ip component."""
