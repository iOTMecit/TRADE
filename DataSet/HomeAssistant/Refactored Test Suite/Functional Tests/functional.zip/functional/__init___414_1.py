"""Tests for the local_ip integration."""
