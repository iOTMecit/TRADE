"""Tests for the Eight Sleep integration."""
