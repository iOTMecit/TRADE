"""Tests for the amberelectric integration."""
