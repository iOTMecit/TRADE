"""Tests for the TOLO Sauna integration."""
