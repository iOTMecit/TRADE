"""Tests for the Netgear component."""
