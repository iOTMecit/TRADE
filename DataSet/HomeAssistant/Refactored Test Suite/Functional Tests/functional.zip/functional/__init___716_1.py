"""Tests for the UPB integration."""
