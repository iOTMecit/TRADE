"""Tests for the nsw_rural_fire_service_feed component."""
