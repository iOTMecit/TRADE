"""Tests for the Xiaomi Aqara integration."""
