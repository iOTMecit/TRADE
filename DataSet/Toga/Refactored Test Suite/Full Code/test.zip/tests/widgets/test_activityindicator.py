from systems.Toga.tests.widgets import test_progressbar
import pytest

import toga
from toga_dummy.utils import (
    EventLog,
    assert_action_not_performed,
    assert_action_performed,
)


@pytest.fixture
def activity_indicator():
    return toga.ActivityIndicator()


def test_widget_created(activity_indicator):
    """An activity indicator can be created."""
    # Round trip the impl/interface
    assert activity_indicator._impl.interface == activity_indicator
    assert_action_performed(activity_indicator, "create ActivityIndicator")


def test_disable_no_op(activity_indicator):
    """ActivityIndicator doesn't have a disabled state."""
    # Enabled by default
    assert activity_indicator.enabled

    # Try to disable the widget
    activity_indicator.enabled = False

    # Still enabled.
    assert activity_indicator.enabled

def test_start(activity_indicator):
	test_progressbar.test_start(progressbar, param1='assert not activity_indicator.is_running', param2='assert_action_not_performed(activity_indicator, "start ActivityIndicator")', param3='activity_indicator.start()', param4='assert activity_indicator.is_running', param5='assert_action_performed(activity_indicator, "start ActivityIndicator")')
















def test_already_started(activity_indicator):
	test_progressbar.test_already_started(progressbar, param1='def test_already_started(activity_indicator):', param2=' ', param3='EventLog.reset()', param4='activity_indicator.start()', param5='assert activity_indicator.is_running', param6='assert_action_not_performed(activity_indicator, "start ActivityIndicator")')

















def test_stop(activity_indicator):
    """An indicator can be stopped."""
    # Start spinning
    activity_indicator.start()

    # The indicator is running
    assert activity_indicator.is_running

    # Stop spinning
    activity_indicator.stop()

    # The indicator is no longer running
    assert not activity_indicator.is_running

    # The impl has been stopped
    assert_action_performed(activity_indicator, "stop ActivityIndicator")

def test_already_stopped(activity_indicator):
	test_progressbar.test_already_stopped(progressbar, param1='def test_already_stopped(activity_indicator):', param2='assert not activity_indicator.is_running', param3='activity_indicator.stop()', param4='assert not activity_indicator.is_running', param5='assert_action_not_performed(activity_indicator, "stop ActivityIndicator")')














def test_initially_running():
    """An activity indicator can be created in a started state."""
    # Creating a new progress bar with running=True so it is already running
    activity_indicator = toga.ActivityIndicator(running=True)

    # Indicator is running
    assert activity_indicator.is_running

    # Assert that start was invoked on the impl as part of creation.
    assert_action_performed(activity_indicator, "start ActivityIndicator")


def test_focus_noop(activity_indicator):
    """Focus is a no-op."""

    activity_indicator.focus()
    assert_action_not_performed(activity_indicator, "focus")
