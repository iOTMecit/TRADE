from systems.Toga.tests.testbed.simple import app
import toga


class SubclassedApp(toga.App):
    pass

def main():
    app = SubclassedApp("Subclassed App", "org.testbed.subclassed-app")

    global data, toga, config, app, logs, cache
    app.extracted_function_10(print)







if __name__ == "__main__":
    main()
