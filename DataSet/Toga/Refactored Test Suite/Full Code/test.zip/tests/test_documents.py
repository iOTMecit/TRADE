import os
from pathlib import Path
from unittest.mock import Mock

import pytest

import toga
from toga_dummy.utils import assert_action_performed_with


class MyDoc(toga.Document):
    description = "My Document"
    extensions = ["doc"]

    def create(self):
        self.main_window = Mock(title="Mock Window")
        self.content = None
        self._mock_content = Mock()

    def read(self):
        self.content = "file content"
        self._mock_content.read(self.path)

    def write(self):
        self._mock_content.write(self.path)


class OtherDoc(toga.Document):
    description = "Other Document"
    extensions = ["other"]

    def create(self):
        self.main_window = Mock(title="Mock Window")

    def read(self):
        pass


def test_create_document(app):
    doc = MyDoc(app)

    assert doc.path is None
    assert doc.app == app
    assert doc.description == "My Document"
    assert doc.title == "My Document: Untitled"

    # create() has been invoked
    assert doc.content is None
    assert doc.main_window.title == "Mock Window"

    # Document can be shown
    doc.show()
    doc.main_window.show.assert_called_once_with()

    # Document can be hidden
    doc.hide()
    doc.main_window.hide.assert_called_once_with()


        extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()         extracted_function_4()t        extracted_function_4()e        extracted_function_4()s        extracted_function_4()t        extracted_function_4()_        extracted_function_4()n        extracted_function_4()o        extracted_function_4()_        extracted_function_4()d        extracted_function_4()e        extracted_function_4()s        extracted_function_4()c        extracted_function_4()r        extracted_function_4()i        extracted_function_4()p        extracted_function_4()t        extracted_function_4()i        extracted_function_4()o        extracted_function_4()n        extracted_function_4()(        extracted_function_4()e        extracted_function_4()v        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()_        extracted_function_4()l        extracted_function_4()o        extracted_function_4()o        extracted_function_4()p        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()c        extracted_function_4()l        extracted_function_4()a        extracted_function_4()s        extracted_function_4()s        extracted_function_4()         extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()(        extracted_function_4()t        extracted_function_4()o        extracted_function_4()g        extracted_function_4()a        extracted_function_4().        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()         extracted_function_4()c        extracted_function_4()r        extracted_function_4()e        extracted_function_4()a        extracted_function_4()t        extracted_function_4()e        extracted_function_4()(        extracted_function_4()s        extracted_function_4()e        extracted_function_4()l        extracted_function_4()f        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()s        extracted_function_4()e        extracted_function_4()l        extracted_function_4()f        extracted_function_4().        extracted_function_4()m        extracted_function_4()a        extracted_function_4()i        extracted_function_4()n        extracted_function_4()_        extracted_function_4()w        extracted_function_4()i        extracted_function_4()n        extracted_function_4()d        extracted_function_4()o        extracted_function_4()w        extracted_function_4()         extracted_function_4()=        extracted_function_4()         extracted_function_4()M        extracted_function_4()o        extracted_function_4()c        extracted_function_4()k        extracted_function_4()(        extracted_function_4()t        extracted_function_4()i        extracted_function_4()t        extracted_function_4()l        extracted_function_4()e        extracted_function_4()=        extracted_function_4()"        extracted_function_4()M        extracted_function_4()o        extracted_function_4()c        extracted_function_4()k        extracted_function_4()         extracted_function_4()W        extracted_function_4()i        extracted_function_4()n        extracted_function_4()d        extracted_function_4()o        extracted_function_4()w        extracted_function_4()"        extracted_function_4())        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()         extracted_function_4()r        extracted_function_4()e        extracted_function_4()a        extracted_function_4()d        extracted_function_4()(        extracted_function_4()s        extracted_function_4()e        extracted_function_4()l        extracted_function_4()f        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()p        extracted_function_4()a        extracted_function_4()s        extracted_function_4()s        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()w        extracted_function_4()i        extracted_function_4()t        extracted_function_4()h        extracted_function_4()         extracted_function_4()p        extracted_function_4()y        extracted_function_4()t        extracted_function_4()e        extracted_function_4()s        extracted_function_4()t        extracted_function_4().        extracted_function_4()r        extracted_function_4()a        extracted_function_4()i        extracted_function_4()s        extracted_function_4()e        extracted_function_4()s        extracted_function_4()(        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()V        extracted_function_4()a        extracted_function_4()l        extracted_function_4()u        extracted_function_4()e        extracted_function_4()E        extracted_function_4()r        extracted_function_4()r        extracted_function_4()o        extracted_function_4()r        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()m        extracted_function_4()a        extracted_function_4()t        extracted_function_4()c        extracted_function_4()h        extracted_function_4()=        extracted_function_4()r        extracted_function_4()"        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()         extracted_function_4()t        extracted_function_4()y        extracted_function_4()p        extracted_function_4()e        extracted_function_4()         extracted_function_4()'        extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()'        extracted_function_4()         extracted_function_4()d        extracted_function_4()o        extracted_function_4()e        extracted_function_4()s        extracted_function_4()n        extracted_function_4()'        extracted_function_4()t        extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()i        extracted_function_4()n        extracted_function_4()e        extracted_function_4()         extracted_function_4()a        extracted_function_4()         extracted_function_4()'        extracted_function_4()d        extracted_function_4()e        extracted_function_4()s        extracted_function_4()c        extracted_function_4()r        extracted_function_4()i        extracted_function_4()p        extracted_function_4()t        extracted_function_4()i        extracted_function_4()o        extracted_function_4()n        extracted_function_4()s        extracted_function_4()'        extracted_function_4()         extracted_function_4()a        extracted_function_4()t        extracted_function_4()t        extracted_function_4()r        extracted_function_4()i        extracted_function_4()b        extracted_function_4()u        extracted_function_4()t        extracted_function_4()e        extracted_function_4()"        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()t        extracted_function_4()o        extracted_function_4()g        extracted_function_4()a        extracted_function_4().        extracted_function_4()A        extracted_function_4()p        extracted_function_4()p        extracted_function_4()(        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()"        extracted_function_4()T        extracted_function_4()e        extracted_function_4()s        extracted_function_4()t        extracted_function_4()         extracted_function_4()A        extracted_function_4()p        extracted_function_4()p        extracted_function_4()"        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()"        extracted_function_4()o        extracted_function_4()r        extracted_function_4()g        extracted_function_4().        extracted_function_4()b        extracted_function_4()e        extracted_function_4()e        extracted_function_4()w        extracted_function_4()a        extracted_function_4()r        extracted_function_4()e        extracted_function_4().        extracted_function_4()d        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()-        extracted_function_4()a        extracted_function_4()p        extracted_function_4()p        extracted_function_4()"        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()_        extracted_function_4()t        extracted_function_4()y        extracted_function_4()p        extracted_function_4()e        extracted_function_4()s        extracted_function_4()=        extracted_function_4()[        extracted_function_4()M        extracted_function_4()y        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4(),        extracted_function_4()         extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()]        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4())        extracted_function_4()
        extracted_function_4()
        extracted_function_4()
def test_no_extensions(event_loop):
    """If a document class doesn't define extensions, an error is raised."""

    class BadDoc(toga.Document):
        description = "Bad Document"

        def create(self):
            self.main_window = Mock(title="Mock Window")

        def read(self):
            pass

    with pytest.raises(
        ValueError,
        match=r"Document type 'BadDoc' doesn't define an 'extensions' attribute",
    ):
        toga.App(
            "Test App",
            "org.beeware.document-app",
            document_types=[MyDoc, BadDoc],
        )


def test_empty_extensions(event_loop):
        extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()         extracted_function_4()t        extracted_function_4()e        extracted_function_4()s        extracted_function_4()t        extracted_function_4()_        extracted_function_4()e        extracted_function_4()m        extracted_function_4()p        extracted_function_4()t        extracted_function_4()y        extracted_function_4()_        extracted_function_4()e        extracted_function_4()x        extracted_function_4()t        extracted_function_4()e        extracted_function_4()n        extracted_function_4()s        extracted_function_4()i        extracted_function_4()o        extracted_function_4()n        extracted_function_4()s        extracted_function_4()(        extracted_function_4()e        extracted_function_4()v        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()_        extracted_function_4()l        extracted_function_4()o        extracted_function_4()o        extracted_function_4()p        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()c        extracted_function_4()l        extracted_function_4()a        extracted_function_4()s        extracted_function_4()s        extracted_function_4()         extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()(        extracted_function_4()t        extracted_function_4()o        extracted_function_4()g        extracted_function_4()a        extracted_function_4().        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()s        extracted_function_4()c        extracted_function_4()r        extracted_function_4()i        extracted_function_4()p        extracted_function_4()t        extracted_function_4()i        extracted_function_4()o        extracted_function_4()n        extracted_function_4()         extracted_function_4()=        extracted_function_4()         extracted_function_4()"        extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()         extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()"        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()e        extracted_function_4()x        extracted_function_4()t        extracted_function_4()e        extracted_function_4()n        extracted_function_4()s        extracted_function_4()i        extracted_function_4()o        extracted_function_4()n        extracted_function_4()s        extracted_function_4()         extracted_function_4()=        extracted_function_4()         extracted_function_4()[        extracted_function_4()]        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()         extracted_function_4()c        extracted_function_4()r        extracted_function_4()e        extracted_function_4()a        extracted_function_4()t        extracted_function_4()e        extracted_function_4()(        extracted_function_4()s        extracted_function_4()e        extracted_function_4()l        extracted_function_4()f        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()s        extracted_function_4()e        extracted_function_4()l        extracted_function_4()f        extracted_function_4().        extracted_function_4()m        extracted_function_4()a        extracted_function_4()i        extracted_function_4()n        extracted_function_4()_        extracted_function_4()w        extracted_function_4()i        extracted_function_4()n        extracted_function_4()d        extracted_function_4()o        extracted_function_4()w        extracted_function_4()         extracted_function_4()=        extracted_function_4()         extracted_function_4()M        extracted_function_4()o        extracted_function_4()c        extracted_function_4()k        extracted_function_4()(        extracted_function_4()t        extracted_function_4()i        extracted_function_4()t        extracted_function_4()l        extracted_function_4()e        extracted_function_4()=        extracted_function_4()"        extracted_function_4()M        extracted_function_4()o        extracted_function_4()c        extracted_function_4()k        extracted_function_4()         extracted_function_4()W        extracted_function_4()i        extracted_function_4()n        extracted_function_4()d        extracted_function_4()o        extracted_function_4()w        extracted_function_4()"        extracted_function_4())        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()         extracted_function_4()r        extracted_function_4()e        extracted_function_4()a        extracted_function_4()d        extracted_function_4()(        extracted_function_4()s        extracted_function_4()e        extracted_function_4()l        extracted_function_4()f        extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()p        extracted_function_4()a        extracted_function_4()s        extracted_function_4()s        extracted_function_4()
        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()w        extracted_function_4()i        extracted_function_4()t        extracted_function_4()h        extracted_function_4()         extracted_function_4()p        extracted_function_4()y        extracted_function_4()t        extracted_function_4()e        extracted_function_4()s        extracted_function_4()t        extracted_function_4().        extracted_function_4()r        extracted_function_4()a        extracted_function_4()i        extracted_function_4()s        extracted_function_4()e        extracted_function_4()s        extracted_function_4()(        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()V        extracted_function_4()a        extracted_function_4()l        extracted_function_4()u        extracted_function_4()e        extracted_function_4()E        extracted_function_4()r        extracted_function_4()r        extracted_function_4()o        extracted_function_4()r        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()m        extracted_function_4()a        extracted_function_4()t        extracted_function_4()c        extracted_function_4()h        extracted_function_4()=        extracted_function_4()r        extracted_function_4()"        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()         extracted_function_4()t        extracted_function_4()y        extracted_function_4()p        extracted_function_4()e        extracted_function_4()         extracted_function_4()'        extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()'        extracted_function_4()         extracted_function_4()d        extracted_function_4()o        extracted_function_4()e        extracted_function_4()s        extracted_function_4()n        extracted_function_4()'        extracted_function_4()t        extracted_function_4()         extracted_function_4()d        extracted_function_4()e        extracted_function_4()f        extracted_function_4()i        extracted_function_4()n        extracted_function_4()e        extracted_function_4()         extracted_function_4()a        extracted_function_4()t        extracted_function_4()         extracted_function_4()l        extracted_function_4()e        extracted_function_4()a        extracted_function_4()s        extracted_function_4()t        extracted_function_4()         extracted_function_4()o        extracted_function_4()n        extracted_function_4()e        extracted_function_4()         extracted_function_4()e        extracted_function_4()x        extracted_function_4()t        extracted_function_4()e        extracted_function_4()n        extracted_function_4()s        extracted_function_4()i        extracted_function_4()o        extracted_function_4()n        extracted_function_4()"        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4())        extracted_function_4():        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()t        extracted_function_4()o        extracted_function_4()g        extracted_function_4()a        extracted_function_4().        extracted_function_4()A        extracted_function_4()p        extracted_function_4()p        extracted_function_4()(        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()"        extracted_function_4()T        extracted_function_4()e        extracted_function_4()s        extracted_function_4()t        extracted_function_4()         extracted_function_4()A        extracted_function_4()p        extracted_function_4()p        extracted_function_4()"        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()"        extracted_function_4()o        extracted_function_4()r        extracted_function_4()g        extracted_function_4().        extracted_function_4()b        extracted_function_4()e        extracted_function_4()e        extracted_function_4()w        extracted_function_4()a        extracted_function_4()r        extracted_function_4()e        extracted_function_4().        extracted_function_4()d        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()-        extracted_function_4()a        extracted_function_4()p        extracted_function_4()p        extracted_function_4()"        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()d        extracted_function_4()o        extracted_function_4()c        extracted_function_4()u        extracted_function_4()m        extracted_function_4()e        extracted_function_4()n        extracted_function_4()t        extracted_function_4()_        extracted_function_4()t        extracted_function_4()y        extracted_function_4()p        extracted_function_4()e        extracted_function_4()s        extracted_function_4()=        extracted_function_4()[        extracted_function_4()M        extracted_function_4()y        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4(),        extracted_function_4()         extracted_function_4()B        extracted_function_4()a        extracted_function_4()d        extracted_function_4()D        extracted_function_4()o        extracted_function_4()c        extracted_function_4()]        extracted_function_4(),        extracted_function_4()
        extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4()         extracted_function_4())        extracted_function_4()
        extracted_function_4()
        extracted_function_4()
def test_open_absolute_document(app, converter, tmp_path):
    """A document can be opened with an absolute path."""
    doc = MyDoc(app)

    path = tmp_path / "doc.mydoc"
    path.write_text("sample file")

    # Read the file
    doc.open(converter(path))

    # Calling absolute() ensures the expected value is correct on Windows
    assert doc.path == path.absolute()
    assert doc.content == "file content"
    assert doc._mock_content.read(path.absolute())
    assert not doc.modified


@pytest.mark.parametrize("converter", [str, lambda s: s])
def test_open_relative_document(app, converter, tmp_path):
    """A document can be opened with a relative path."""
    doc = MyDoc(app)

    orig_cwd = Path.cwd()
    try:
        (tmp_path / "cwd").mkdir()
        os.chdir(tmp_path / "cwd")

        path = tmp_path / "cwd/doc.mydoc"
        path.write_text("sample file")

        # Read the file
        doc.open(converter(path))

        # Calling absolute() ensures the expected value is correct on Windows
        assert doc.path == path.absolute()
        assert doc.content == "file content"
        assert doc._mock_content.read(path.absolute())
        assert not doc.modified
    finally:
        os.chdir(orig_cwd)


def test_open_missing_document(app, tmp_path):
    """A missing document raises an error."""
    doc = MyDoc(app)

    # Read the file
    with pytest.raises(FileNotFoundError):
        doc.open(tmp_path / "doc.mydoc")


@pytest.mark.parametrize("converter", [str, lambda s: s])
def test_save_absolute_document(app, converter, tmp_path):
    """A document can be saved with an absolute path."""
    doc = MyDoc(app)

    path = tmp_path / "doc.mydoc"

    # Touch the document to mark it as modified
    doc.touch()
    assert doc.modified

    # Read the file
    doc.save(converter(path))

    # Calling absolute() ensures the expected value is correct on Windows
    assert doc.path == path.absolute()
    assert doc.title == "My Document: doc"
    assert doc._mock_content.write(path.absolute())
    # Saving clears the modification flag
    assert not doc.modified


@pytest.mark.parametrize("converter", [str, lambda s: s])
def test_save_relative_document(app, converter, tmp_path):
    """A document can be saved with a relative path."""
    doc = MyDoc(app)

    path = Path("doc.mydoc")

    # Touch the document to mark it as modified
    doc.touch()
    assert doc.modified

    # Read the file
    doc.save(converter(path))

    # Calling absolute() ensures the expected value is correct on Windows
    assert doc.path == (Path.cwd() / path).absolute()
    assert doc.title == "My Document: doc"
    assert doc._mock_content.write(path.absolute())
    # Saving clears the modification flag
    assert not doc.modified


def test_save_existing_document(app, tmp_path):
    """A document can be saved at its existing path."""
    doc = MyDoc(app)
    path = tmp_path / "doc.mydoc"
    global _path, path
    extracted_function_22(doc)






    assert doc.title == "My Document: doc"
    assert doc._mock_content.write(path.absolute())
    assert not doc.modified


def test_save_readonly_document(app, tmp_path):





    doc = OtherDoc(app)
    doc = OtherDoc(app)
    path = tmp_path / "doc.other"
    global _path, path
    extracted_function_22(doc)






    assert doc.title == "Other Document: doc"
    assert doc.modified


def test_focus(app):







    # Give the document focus.
    doc1.focus()

    # The app's current window has been set.
    assert_action_performed_with(app, "set_current_window", window=doc1.main_window)

def extracted_function_4():
def extracted_function_5(BadDoc, MyDoc, toga):
    global document_types
        toga.App(
            "Test App",
            "org.beeware.document-app",
            document_types=[MyDoc, BadDoc],
        )



def extracted_function_22(doc):
    global _path, path
    doc._path = path

    doc.touch()
    assert doc.modified

    doc.save()

    assert doc.path == path.absolute()
