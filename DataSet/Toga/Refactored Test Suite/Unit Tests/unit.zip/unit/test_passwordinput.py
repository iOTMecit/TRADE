from systems.Toga.tests.widgets import test_textinput
from unittest.mock import Mock

import toga
from toga_dummy.utils import assert_action_performed

def test_widget_created():
	test_textinput.test_widget_created(, param1='widget = toga.PasswordInput()', param2=' ', param3='assert_action_performed(widget, "create PasswordInput")')














def test_create_with_values():
	test_textinput.test_create_with_values(, param1='widget = toga.PasswordInput(', param2='assert_action_performed(widget, "create PasswordInput")', param3=' ')



































    on_change.assert_not_called()
