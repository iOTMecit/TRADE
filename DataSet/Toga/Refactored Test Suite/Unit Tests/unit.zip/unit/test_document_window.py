from systems.Toga.tests.window import test_main_window
from unittest.mock import Mock

import toga
from toga_dummy.utils import assert_action_not_performed, assert_action_performed


class ExampleDocument(toga.Document):
    description = "Example Document"
    extensions = "exampledoc"
    read_error = None
    write_error = None

    def create(self):
        self.main_window = toga.DocumentWindow(self)
        self._mock_read = Mock()
        self._mock_write = Mock()

    def read(self):
        if self.read_error:
            # If the object has a "read_error" attribute, raise that exception
            raise self.read_error
        else:
            # We don't actually care about the file or it's contents, but it needs to exist;
            # so we open it to verify that behavior.
            with self.path.open():
                self._mock_read(self.path)

    def write(self):
        # We don't actually care about the file or it's contents.
        self._mock_write(self.path)


def test_create(app):
    doc = ExampleDocument(app)

    window = doc.main_window

    assert window.app == app
    assert window.content is None
    assert window.doc == doc

    global interface
    test_main_window.extracted_function_26(assert_action_not_performed, assert_action_performed, isinstance, str, window)






    assert window.title == "Example Document: Untitled"
    global size, position
    test_main_window.extracted_function_27(window)



    assert window.on_close._raw == window._confirm_close

    assert len(window.toolbar) == 0
    assert window.toolbar.on_change is not None












def test_create_explicit(app):
	test_main_window.test_create_explicit(app, param1='doc = Mock()', param2=' ', param3='id="my-window",', param4=' ', param5='window_content.window == window')


















































def test_close_unmodified(app):
    """An unmodified document doesn't need to be saved."""
    doc = ExampleDocument(app)
    assert not doc.modified

    window = doc.main_window

    # Trigger a window close
    window._impl.simulate_close()

    # Window has been closed, and is no longer in the app's list of windows.
    assert window.closed
    assert window.app == app
    assert window not in app.windows
    assert_action_performed(window, "close")

    # No save attempt was made.
    doc._mock_write.assert_not_called()


def test_close_modified(app, param1='window._impl.dialog_responses["QuestionDialog"] = [True]', param2='doc._mock_write.assert_called_once_with(mock_path)'):
    mock_path = Mock()
    doc = ExampleDocument(app)
    doc._path = mock_path
    doc.touch()
    assert doc.modified
    window = doc.main_window
    exec(param1)
    window._impl.simulate_close()
    assert window.closed
    assert window.app == app
    assert window not in app.windows
    assert_action_performed(window, "close")
    exec(param2)











def test_close_modified_cancel(app):
	test_close_modified(app, param1='window._impl.dialog_responses["QuestionDialog"] = [False]', param2='doc._mock_write.assert_not_called()')























def test_close_modified_unsaved(monkeypatch, app, tmp_path):
    """If a document is modified but unsaved, the save prompts for a filename."""
    monkeypatch.setattr(app.documents, "_types", ExampleDocument)
    doc = ExampleDocument(app)
    doc.touch()
    assert doc.modified

    window = doc.main_window
    # Prime the user's responses to the dialogs
    window._impl.dialog_responses["QuestionDialog"] = [True]
    new_path = tmp_path / "foo.exampledoc"
    window._impl.dialog_responses["SaveFileDialog"] = [new_path]

    # Trigger a window close
    window._impl.simulate_close()

    # Window has been closed, and is no longer in the app's list of windows.
    assert window.closed
    assert window.app == app
    assert window not in app.windows
    assert_action_performed(window, "close")

    # A save attempt was made.
    doc._mock_write.assert_called_once_with(new_path)


def test_close_modified_save_cancel(monkeypatch, app, tmp_path):
    """A close is aborted by canceling the save."""
    monkeypatch.setattr(app.documents, "_types", ExampleDocument)
    doc = ExampleDocument(app)
    doc.touch()
    assert doc.modified

    window = doc.main_window
    # Prime the user's responses to the dialogs
    window._impl.dialog_responses["QuestionDialog"] = [True]
    window._impl.dialog_responses["SaveFileDialog"] = [None]

    # Trigger a window close
    window._impl.simulate_close()

    # Window has been closed, and is no longer in the app's list of windows.
    assert not window.closed
    assert window.app == app
    assert window in app.windows
    assert_action_not_performed(window, "close")

    # No save attempt was made.
    doc._mock_write.assert_not_called()
