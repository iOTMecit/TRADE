from unittest.mock import Mock

import pytest

import toga
from toga_dummy.utils import EventLog, assert_action_performed, attribute_value


@pytest.fixture
def widget():
    return toga.MultilineTextInput()


def test_widget_created(widget):
    """A multiline text input."""
    assert widget._impl.interface == widget
    assert_action_performed(widget, "create MultilineTextInput")

    assert not widget.readonly
    assert widget.placeholder == ""
    assert widget.value == ""
    assert widget._on_change._raw is None


def test_create_with_values():
    """A multiline text input can be created with initial values."""
    on_change = Mock()
    widget = toga.MultilineTextInput(
        value="Some text",
        placeholder="A placeholder",
        readonly=True,
        on_change=on_change,
    )
    assert widget._impl.interface == widget
    assert_action_performed(widget, "create MultilineTextInput")

    assert widget.readonly
    assert widget.placeholder == "A placeholder"
    assert widget.value == "Some text"
    assert widget._on_change._raw == on_change

    # Change handler hasn't been invoked
    on_change.assert_not_called()


@pytest.mark.parametrize(
    "value, expected",
    [
        ("New Text", "New Text"),
        ("", ""),
        (None, ""),
        (12345, "12345"),
        ("Contains\nnewline", "Contains\nnewline"),
    ],
)
def test_value(widget, value, expected, param1='handler = Mock()', param2='widget.on_change = handler', param3='handler.assert_called_once_with(widget)'):
    EventLog.reset()
    exec(param1)
    exec(param2)
    widget.value = value
    assert widget.value == expected
    assert attribute_value(widget, "value") == expected
    assert_action_performed(widget, "refresh")
    exec(param3)













@pytest.mark.parametrize(
    "value, expected",
    [
        (None, False),
        ("", False),
        ("true", True),
        ("false", True),  # Evaluated as a string, this value is true.
        (0, False),
        (1234, True),
    ],
)
def test_readonly(widget, value, expected, ):
    assert not widget.readonly
    widget.readonly = value
    assert widget.readonly == expected
    widget.readonly = True
    assert widget.readonly
    widget.readonly = value
    assert widget.readonly == expected










@pytest.mark.parametrize(
    "value, expected",
    [
        ("New Text", "New Text"),
        ("", ""),
        (None, ""),
        (12345, "12345"),
        ("Contains\nnewline", "Contains\nnewline"),
    ],
)
def test_placeholder(widget, value, expected):
    """The value of the placeholder can be set."""
    # Clear the event log
    EventLog.reset()

    widget.placeholder = value
    assert widget.placeholder == expected

    # test backend has the right value
    assert attribute_value(widget, "placeholder") == expected

    # A refresh was performed
    assert_action_performed(widget, "refresh")


def test_scroll(widget):
    """The widget can be scrolled programmatically."""
    # Clear the event log
    EventLog.reset()

    widget.scroll_to_top()

    # A refresh was performed
    assert_action_performed(widget, "scroll to top")

    # Clear the event log
    EventLog.reset()

    widget.scroll_to_bottom()

    # The widget has been scrolled
    assert_action_performed(widget, "scroll to bottom")


def test_on_change(widget, param1='assert widget._on_change._raw is None', param2='handler = Mock()', param3='widget.on_change = handler', param4='assert widget.on_change._raw == handler', param5='widget._impl.simulate_change()', param6='handler.assert_called_once_with(widget)', param7=' '):
    exec(param1)
    exec(param2)
    exec(param3)
    exec(param4)
    exec(param5)
    exec(param6)
    exec(param7)









