from systems.Toga.toga.tests.style.pack.layout import test_column_alignment
from toga.style.pack import BOTTOM, COLUMN, LEFT, RIGHT, ROW, RTL, TOP, Pack

from ..utils import ExampleNode, ExampleViewport, assert_layout


def test_row_box_child_layout(, param1='style=Pack(text_direction=RTL, direction=ROW),', param2='style=Pack(width=30, height=100, padding_left=32, padding_right=34),', param3='style=Pack(width=36, height=100, padding_left=38, padding_right=40),', param4='(210, 100),', param5='{"origin": (576, 0), "content": (30, 100)},', param6='{"origin": (468, 0), "content": (36, 100)},'):
    root = ExampleNode(
        "container",
        exec(param1)
        children=[
            ExampleNode(
                "widget_a",
                exec(param2)
            ),
            ExampleNode(
                "widget_b",
                exec(param3)
            ),
        ],
    )
    root.style.layout(root, ExampleViewport(640, 480))
    assert_layout(
        root,
        exec(param4)
        (640, 480),
        {
            "origin": (0, 0),
            "content": (640, 480),
            "children": [
                exec(param5)
                exec(param6)
            ],
        },
    )



def test_column_box_child_layout():
	test_row_box_child_layout(, param1='style=Pack(text_direction=RTL, direction=COLUMN),', param2='style=Pack(width=100, height=30, padding_top=32, padding_bottom=34),', param3='style=Pack(width=100, height=36, padding_top=38, padding_bottom=40),', param4='(100, 210),', param5='{"origin": (0, 32), "content": (100, 30)},', param6='{"origin": (0, 134), "content": (100, 36)},')






























def test_alignment_top():
	test_column_alignment.test_no_padding(, param1='style=Pack(text_direction=RTL, direction=ROW, alignment=TOP),', param2='ExampleNode("space_filler", style=Pack(width=30, height=100)),', param3='ExampleNode("widget", style=Pack(width=30, height=30)),', param4='(60, 100),', param5='(640, 480),', param6='"content": (640, 480),', param7='{"origin": (610, 0), "content": (30, 100)},', param8='{"origin": (580, 0), "content": (30, 30)},')

























def test_alignment_bottom():
    root = ExampleNode(
        "root",
        style=Pack(text_direction=RTL, direction=ROW, alignment=BOTTOM),
        children=[
            ExampleNode("space_filler", style=Pack(width=30, height=100)),
            ExampleNode("widget", style=Pack(width=30, height=30)),
        ],
    )

    root.style.layout(root, ExampleViewport(640, 480))
    assert_layout(
        root,
        (60, 100),
        (640, 480),
        {
            "origin": (0, 0),
            "content": (640, 480),
            "children": [
                {"origin": (610, 380), "content": (30, 100)},
                {"origin": (580, 450), "content": (30, 30)},
            ],
        },
    )


def test_alignment_left():
    root = ExampleNode(
        "root",
        style=Pack(text_direction=RTL, direction=COLUMN, alignment=LEFT),
        children=[
            ExampleNode("space_filler", style=Pack(width=100, height=30)),
            ExampleNode("widget", style=Pack(width=30, height=30)),
        ],
    )

    root.style.layout(root, ExampleViewport(640, 480))
    assert_layout(
        root,
        (100, 60),
        (640, 480),
        {
            "origin": (0, 0),
            "content": (640, 480),
            "children": [
                {"origin": (0, 0), "content": (100, 30)},
                {"origin": (0, 30), "content": (30, 30)},
            ],
        },
    )


def test_alignment_right():
    root = ExampleNode(
        "root",
        style=Pack(text_direction=RTL, direction=COLUMN, alignment=RIGHT),
        children=[
            ExampleNode("space_filler", style=Pack(width=100, height=30)),
            ExampleNode("widget", style=Pack(width=30, height=30)),
        ],
    )

    root.style.layout(root, ExampleViewport(640, 480))
    assert_layout(
        root,
        (100, 60),
        (640, 480),
        {
            "origin": (0, 0),
            "content": (640, 480),
            "children": [
                {"origin": (540, 0), "content": (100, 30)},
                {"origin": (610, 30), "content": (30, 30)},
            ],
        },
    )
