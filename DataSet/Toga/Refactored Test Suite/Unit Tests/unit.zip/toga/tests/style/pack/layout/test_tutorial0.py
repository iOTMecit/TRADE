from travertino.size import at_least

from toga.style.pack import COLUMN, Pack

from ..utils import ExampleNode, ExampleViewport, assert_layout


def test_tutorial_0(, param1='style=Pack(),', param2='"button", style=Pack(flex=1, padding=50), size=(at_least(120), 30)', param3='root.style.layout(root, ExampleViewport(640, 480))', param4='(220, 130),', param5='(640, 480),', param6='"content": (640, 480),', param7='"children": [{"origin": (50, 50), "content": (540, 30)}],'):
    root = ExampleNode(
        "app",
        exec(param1)
        children=[
            ExampleNode(
                exec(param2)
            ),
        ],
    )
    exec(param3)
    assert_layout(
        root,
        exec(param4)
        exec(param5)
        {
            "origin": (0, 0),
            exec(param6)
            exec(param7)
        },
    )



def test_vertical():
	test_tutorial_0(, param1='style=Pack(direction=COLUMN),', param2='"button", style=Pack(flex=1, padding=50), size=(30, at_least(120))', param3='root.style.layout(root, ExampleViewport(480, 640))', param4='(130, 220),', param5='(480, 640),', param6='"content": (480, 640),', param7='"children": [{"origin": (50, 50), "content": (30, 540)}],')





















