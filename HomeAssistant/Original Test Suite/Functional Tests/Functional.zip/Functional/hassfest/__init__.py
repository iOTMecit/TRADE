"""Tests for hassfest."""
