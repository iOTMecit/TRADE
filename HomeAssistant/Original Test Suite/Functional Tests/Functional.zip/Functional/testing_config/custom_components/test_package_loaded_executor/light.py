"""Provide a mock light platform."""
