"""Tests for Home Assistant."""
