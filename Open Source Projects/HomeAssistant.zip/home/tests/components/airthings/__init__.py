"""Tests for the Airthings integration."""
