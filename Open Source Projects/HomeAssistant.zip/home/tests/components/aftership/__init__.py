"""Tests for the AfterShip integration."""
