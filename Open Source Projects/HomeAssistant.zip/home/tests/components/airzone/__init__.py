"""Tests for the Airzone integration."""
