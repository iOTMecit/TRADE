"""Define tests for the AirVisual component."""
