"""Tests for the Aladdin Connect Garage Door integration."""
