"""Tests for the Airzone Cloud integration."""
