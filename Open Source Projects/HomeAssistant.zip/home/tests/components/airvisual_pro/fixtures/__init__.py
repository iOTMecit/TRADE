"""Define data fixtures for AirVisual Pro."""
