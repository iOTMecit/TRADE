"""Tests for the AirVisual Pro integration."""
