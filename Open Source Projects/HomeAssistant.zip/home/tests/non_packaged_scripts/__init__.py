"""Tests for the non-packaged scripts in the script directory."""
